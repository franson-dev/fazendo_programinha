﻿namespace fazendo_programinha
{
    partial class super_calculadora
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(super_calculadora));
            this.gb_numbers = new System.Windows.Forms.GroupBox();
            this.b_common = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.b_more_and_less = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.gb_operations = new System.Windows.Forms.GroupBox();
            this.b_equal = new System.Windows.Forms.Button();
            this.b_adition = new System.Windows.Forms.Button();
            this.b_multiplication = new System.Windows.Forms.Button();
            this.b_pow = new System.Windows.Forms.Button();
            this.b_percentage = new System.Windows.Forms.Button();
            this.b_subtraction = new System.Windows.Forms.Button();
            this.b_division = new System.Windows.Forms.Button();
            this.lb_view = new System.Windows.Forms.Label();
            this.gb_delete = new System.Windows.Forms.GroupBox();
            this.b_backspace = new System.Windows.Forms.Button();
            this.b_ce = new System.Windows.Forms.Button();
            this.b_c = new System.Windows.Forms.Button();
            this.lbHistoric = new System.Windows.Forms.Label();
            this.gb_numbers.SuspendLayout();
            this.gb_operations.SuspendLayout();
            this.gb_delete.SuspendLayout();
            this.SuspendLayout();
            // 
            // gb_numbers
            // 
            this.gb_numbers.Controls.Add(this.b_common);
            this.gb_numbers.Controls.Add(this.button12);
            this.gb_numbers.Controls.Add(this.button7);
            this.gb_numbers.Controls.Add(this.button8);
            this.gb_numbers.Controls.Add(this.button9);
            this.gb_numbers.Controls.Add(this.button4);
            this.gb_numbers.Controls.Add(this.button5);
            this.gb_numbers.Controls.Add(this.b_more_and_less);
            this.gb_numbers.Controls.Add(this.button6);
            this.gb_numbers.Controls.Add(this.button3);
            this.gb_numbers.Controls.Add(this.button2);
            this.gb_numbers.Controls.Add(this.button1);
            this.gb_numbers.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb_numbers.Location = new System.Drawing.Point(3, 174);
            this.gb_numbers.Name = "gb_numbers";
            this.gb_numbers.Size = new System.Drawing.Size(303, 369);
            this.gb_numbers.TabIndex = 0;
            this.gb_numbers.TabStop = false;
            this.gb_numbers.Enter += new System.EventHandler(this.gb_numbers_Enter);
            // 
            // b_common
            // 
            this.b_common.BackColor = System.Drawing.Color.Transparent;
            this.b_common.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_common.BackgroundImage")));
            this.b_common.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_common.FlatAppearance.BorderSize = 0;
            this.b_common.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_common.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_common.Location = new System.Drawing.Point(200, 278);
            this.b_common.Name = "b_common";
            this.b_common.Size = new System.Drawing.Size(88, 78);
            this.b_common.TabIndex = 11;
            this.b_common.Text = ",";
            this.b_common.UseVisualStyleBackColor = false;
            this.b_common.Click += new System.EventHandler(this.numbers);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.Transparent;
            this.button12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button12.BackgroundImage")));
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(105, 278);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(88, 78);
            this.button12.TabIndex = 9;
            this.button12.Text = "0";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.numbers);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Transparent;
            this.button7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button7.BackgroundImage")));
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(11, 22);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(87, 78);
            this.button7.TabIndex = 8;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.numbers);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Transparent;
            this.button8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button8.BackgroundImage")));
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button8.FlatAppearance.BorderSize = 0;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(104, 22);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(88, 78);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.numbers);
            // 
            // button9
            // 
            this.button9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button9.BackgroundImage")));
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(199, 22);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(88, 78);
            this.button9.TabIndex = 6;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.numbers);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Transparent;
            this.button4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button4.BackgroundImage")));
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(12, 108);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 78);
            this.button4.TabIndex = 5;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.numbers);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Transparent;
            this.button5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button5.BackgroundImage")));
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(105, 108);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(88, 78);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.numbers);
            // 
            // b_more_and_less
            // 
            this.b_more_and_less.BackColor = System.Drawing.Color.Transparent;
            this.b_more_and_less.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_more_and_less.BackgroundImage")));
            this.b_more_and_less.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_more_and_less.FlatAppearance.BorderSize = 0;
            this.b_more_and_less.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_more_and_less.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_more_and_less.Location = new System.Drawing.Point(14, 283);
            this.b_more_and_less.Name = "b_more_and_less";
            this.b_more_and_less.Size = new System.Drawing.Size(86, 75);
            this.b_more_and_less.TabIndex = 15;
            this.b_more_and_less.Text = "+/-";
            this.b_more_and_less.UseVisualStyleBackColor = false;
            this.b_more_and_less.Click += new System.EventHandler(this.b_more_and_less_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Transparent;
            this.button6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button6.BackgroundImage")));
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.FlatAppearance.BorderSize = 0;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(200, 106);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(88, 78);
            this.button6.TabIndex = 3;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.numbers);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Transparent;
            this.button3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button3.BackgroundImage")));
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(200, 190);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(88, 83);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.numbers);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Old English Text MT", 0.0001F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Transparent;
            this.button2.Location = new System.Drawing.Point(105, 190);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(88, 82);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.numbers);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Playbill", 0.0001F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(10, 190);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 82);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.numbers);
            // 
            // gb_operations
            // 
            this.gb_operations.Controls.Add(this.b_equal);
            this.gb_operations.Controls.Add(this.b_adition);
            this.gb_operations.Controls.Add(this.b_multiplication);
            this.gb_operations.Controls.Add(this.b_pow);
            this.gb_operations.Controls.Add(this.b_percentage);
            this.gb_operations.Controls.Add(this.b_subtraction);
            this.gb_operations.Controls.Add(this.b_division);
            this.gb_operations.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb_operations.Location = new System.Drawing.Point(297, 174);
            this.gb_operations.Name = "gb_operations";
            this.gb_operations.Size = new System.Drawing.Size(138, 374);
            this.gb_operations.TabIndex = 1;
            this.gb_operations.TabStop = false;
            // 
            // b_equal
            // 
            this.b_equal.BackColor = System.Drawing.Color.Transparent;
            this.b_equal.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_equal.BackgroundImage")));
            this.b_equal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_equal.FlatAppearance.BorderSize = 0;
            this.b_equal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_equal.Font = new System.Drawing.Font("Old English Text MT", 0.0001F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_equal.ForeColor = System.Drawing.Color.Transparent;
            this.b_equal.Location = new System.Drawing.Point(0, 238);
            this.b_equal.Name = "b_equal";
            this.b_equal.Size = new System.Drawing.Size(140, 128);
            this.b_equal.TabIndex = 19;
            this.b_equal.Text = "=";
            this.b_equal.UseVisualStyleBackColor = false;
            this.b_equal.Click += new System.EventHandler(this.b_equal_Click);
            // 
            // b_adition
            // 
            this.b_adition.BackColor = System.Drawing.Color.Transparent;
            this.b_adition.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_adition.BackgroundImage")));
            this.b_adition.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_adition.FlatAppearance.BorderSize = 0;
            this.b_adition.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_adition.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_adition.Location = new System.Drawing.Point(72, 152);
            this.b_adition.Name = "b_adition";
            this.b_adition.Size = new System.Drawing.Size(68, 65);
            this.b_adition.TabIndex = 22;
            this.b_adition.Text = "+";
            this.b_adition.UseVisualStyleBackColor = false;
            this.b_adition.Click += new System.EventHandler(this.operations);
            // 
            // b_multiplication
            // 
            this.b_multiplication.BackColor = System.Drawing.Color.Transparent;
            this.b_multiplication.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_multiplication.BackgroundImage")));
            this.b_multiplication.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_multiplication.FlatAppearance.BorderSize = 0;
            this.b_multiplication.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_multiplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_multiplication.Location = new System.Drawing.Point(6, 82);
            this.b_multiplication.Name = "b_multiplication";
            this.b_multiplication.Size = new System.Drawing.Size(66, 65);
            this.b_multiplication.TabIndex = 21;
            this.b_multiplication.Text = "*";
            this.b_multiplication.UseVisualStyleBackColor = false;
            this.b_multiplication.Click += new System.EventHandler(this.operations);
            // 
            // b_pow
            // 
            this.b_pow.BackColor = System.Drawing.Color.Transparent;
            this.b_pow.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_pow.BackgroundImage")));
            this.b_pow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_pow.FlatAppearance.BorderSize = 0;
            this.b_pow.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_pow.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_pow.Location = new System.Drawing.Point(72, 11);
            this.b_pow.Name = "b_pow";
            this.b_pow.Size = new System.Drawing.Size(68, 65);
            this.b_pow.TabIndex = 20;
            this.b_pow.Text = "^";
            this.b_pow.UseVisualStyleBackColor = false;
            this.b_pow.Click += new System.EventHandler(this.operations);
            // 
            // b_percentage
            // 
            this.b_percentage.BackColor = System.Drawing.Color.Transparent;
            this.b_percentage.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_percentage.BackgroundImage")));
            this.b_percentage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_percentage.FlatAppearance.BorderSize = 0;
            this.b_percentage.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_percentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_percentage.Location = new System.Drawing.Point(6, 11);
            this.b_percentage.Name = "b_percentage";
            this.b_percentage.Size = new System.Drawing.Size(66, 65);
            this.b_percentage.TabIndex = 19;
            this.b_percentage.Text = "%";
            this.b_percentage.UseVisualStyleBackColor = false;
            this.b_percentage.Click += new System.EventHandler(this.operations);
            // 
            // b_subtraction
            // 
            this.b_subtraction.BackColor = System.Drawing.Color.Transparent;
            this.b_subtraction.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_subtraction.BackgroundImage")));
            this.b_subtraction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_subtraction.FlatAppearance.BorderSize = 0;
            this.b_subtraction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_subtraction.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_subtraction.Location = new System.Drawing.Point(6, 152);
            this.b_subtraction.Name = "b_subtraction";
            this.b_subtraction.Size = new System.Drawing.Size(66, 65);
            this.b_subtraction.TabIndex = 17;
            this.b_subtraction.Text = "-";
            this.b_subtraction.UseVisualStyleBackColor = false;
            this.b_subtraction.Click += new System.EventHandler(this.operations);
            // 
            // b_division
            // 
            this.b_division.BackColor = System.Drawing.Color.Transparent;
            this.b_division.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_division.BackgroundImage")));
            this.b_division.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_division.FlatAppearance.BorderSize = 0;
            this.b_division.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_division.Font = new System.Drawing.Font("Microsoft Sans Serif", 0.0001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.b_division.Location = new System.Drawing.Point(72, 82);
            this.b_division.Name = "b_division";
            this.b_division.Size = new System.Drawing.Size(68, 65);
            this.b_division.TabIndex = 16;
            this.b_division.Text = "/";
            this.b_division.UseVisualStyleBackColor = false;
            this.b_division.Click += new System.EventHandler(this.operations);
            // 
            // lb_view
            // 
            this.lb_view.BackColor = System.Drawing.Color.White;
            this.lb_view.Font = new System.Drawing.Font("Stencil", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_view.Location = new System.Drawing.Point(8, 34);
            this.lb_view.Name = "lb_view";
            this.lb_view.Size = new System.Drawing.Size(428, 66);
            this.lb_view.TabIndex = 2;
            this.lb_view.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gb_delete
            // 
            this.gb_delete.Controls.Add(this.b_backspace);
            this.gb_delete.Controls.Add(this.b_ce);
            this.gb_delete.Controls.Add(this.b_c);
            this.gb_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gb_delete.Location = new System.Drawing.Point(3, 103);
            this.gb_delete.Name = "gb_delete";
            this.gb_delete.Size = new System.Drawing.Size(427, 78);
            this.gb_delete.TabIndex = 3;
            this.gb_delete.TabStop = false;
            // 
            // b_backspace
            // 
            this.b_backspace.BackColor = System.Drawing.Color.Transparent;
            this.b_backspace.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_backspace.BackgroundImage")));
            this.b_backspace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_backspace.FlatAppearance.BorderSize = 0;
            this.b_backspace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_backspace.Location = new System.Drawing.Point(309, 10);
            this.b_backspace.Name = "b_backspace";
            this.b_backspace.Size = new System.Drawing.Size(100, 68);
            this.b_backspace.TabIndex = 17;
            this.b_backspace.UseVisualStyleBackColor = false;
            this.b_backspace.Click += new System.EventHandler(this.b_backspace_Click);
            // 
            // b_ce
            // 
            this.b_ce.BackColor = System.Drawing.Color.Transparent;
            this.b_ce.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_ce.BackgroundImage")));
            this.b_ce.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_ce.FlatAppearance.BorderSize = 0;
            this.b_ce.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_ce.Location = new System.Drawing.Point(163, 10);
            this.b_ce.Name = "b_ce";
            this.b_ce.Size = new System.Drawing.Size(100, 68);
            this.b_ce.TabIndex = 16;
            this.b_ce.UseVisualStyleBackColor = false;
            this.b_ce.Click += new System.EventHandler(this.b_ce_Click);
            // 
            // b_c
            // 
            this.b_c.BackColor = System.Drawing.Color.Transparent;
            this.b_c.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("b_c.BackgroundImage")));
            this.b_c.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.b_c.FlatAppearance.BorderSize = 0;
            this.b_c.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.b_c.Location = new System.Drawing.Point(23, 10);
            this.b_c.Name = "b_c";
            this.b_c.Size = new System.Drawing.Size(100, 68);
            this.b_c.TabIndex = 15;
            this.b_c.UseVisualStyleBackColor = false;
            this.b_c.Click += new System.EventHandler(this.b_c_Click);
            // 
            // lbHistoric
            // 
            this.lbHistoric.Location = new System.Drawing.Point(3, -1);
            this.lbHistoric.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbHistoric.Name = "lbHistoric";
            this.lbHistoric.Size = new System.Drawing.Size(434, 35);
            this.lbHistoric.TabIndex = 18;
            this.lbHistoric.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbHistoric.Click += new System.EventHandler(this.lbHistoric_Click);
            // 
            // super_calculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(442, 557);
            this.Controls.Add(this.lbHistoric);
            this.Controls.Add(this.gb_delete);
            this.Controls.Add(this.gb_operations);
            this.Controls.Add(this.gb_numbers);
            this.Controls.Add(this.lb_view);
            this.Name = "super_calculadora";
            this.Text = "super_calculadora";
            this.Load += new System.EventHandler(this.super_calculadora_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.super_calculadora_KeyUp);
            this.gb_numbers.ResumeLayout(false);
            this.gb_operations.ResumeLayout(false);
            this.gb_delete.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gb_numbers;
        private System.Windows.Forms.GroupBox gb_operations;
        private System.Windows.Forms.Label lb_view;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button b_common;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button b_equal;
        private System.Windows.Forms.Button b_adition;
        private System.Windows.Forms.Button b_multiplication;
        private System.Windows.Forms.Button b_pow;
        private System.Windows.Forms.Button b_percentage;
        private System.Windows.Forms.Button b_subtraction;
        private System.Windows.Forms.Button b_division;
        private System.Windows.Forms.Button b_more_and_less;
        private System.Windows.Forms.GroupBox gb_delete;
        private System.Windows.Forms.Button b_backspace;
        private System.Windows.Forms.Button b_ce;
        private System.Windows.Forms.Button b_c;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lbHistoric;
    }
}